<?php





echo 'HeLLO this is INdex page';






?>